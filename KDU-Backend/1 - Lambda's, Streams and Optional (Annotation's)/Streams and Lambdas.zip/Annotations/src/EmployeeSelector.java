@FunctionalInterface
public interface EmployeeSelector {
    boolean select(Employee e);
}